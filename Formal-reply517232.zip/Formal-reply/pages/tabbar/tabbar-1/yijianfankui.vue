<template>
	<view class="Hybody">
		<view class="titleText">
			意见反馈
		</view>
		<view class="miList">
			<view class="">
				#iphone客户端意见反馈#
			</view>
			<view class="">

			</view>
		</view>
		<view class="miList">
			<view class="">
				版本10.7.0,iPhone11,8,OS13.5.1,网络WI-FI   
				请填写具体内容                                                 
			</view>
			<view class="">

			</view>
		</view>
		<view class="miList">
			<view class="">
				<input type="text" placeholder="请填写具体内容">
			</view>
		</view>
		<view class="" style="display: flex;
		margin-top: 200upx;
		justify-content: center;
		align-items: center;">
			<view class="tijiao">
				提交
			</view>
		</view>
	</view>
</template>

<script>
	
</script>

<style>
	.Hybody{
		padding: 0 60upx;
		padding-top: 50upx;
		height: 1500upx;
		font-size: 14px;
		background-color: #080808;
		color: #fff;
	}
	.titleText{
		color: rgba(255, 255, 255, 100);
		font-size: 22px;
		text-align: left;
		font-weight: 600;
		font-family: 方正工业黑-标准;
		margin: 40upx 0;
	}
	.miList{
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 30upx 0;
		color:rgba(153, 155, 178, 100);
	}
	.tijiao{
		width: 304upx;
		height: 63upx;
		line-height: 63upx;
		border-radius: 25upx;
		background-color: rgba(149, 70, 232, 100);
		color: rgba(255, 255, 255, 100);
		font-size: 14px;
		text-align: center;
		font-family: Microsoft Yahei;
	}
</style>