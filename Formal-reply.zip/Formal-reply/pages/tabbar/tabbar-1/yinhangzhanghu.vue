<template>
	<view class="Hybody">
		<view class="titleText">
			银行账户
		</view>
		<view class="miList">
			<view class="">
				选择银行
			</view>
			<view class="">
				建设银行>
			</view>
		</view>
		<view class="miList">
			<view class="">
				户名
			</view>
			<view class="">
				1个>
			</view>
		</view>
		<view class="miList">
			<view class="">
				银行卡号
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList">
			<view class="">
				开户行
			</view>
			<view class="">
				>
			</view>
		</view>
	</view>
</template>

<script>
	
</script>

<style>
	.Hybody{
		padding: 0 60upx;
		padding-top: 50upx;
		height: 1500upx;
		font-size: 14px;
		background-color: #080808;
		color: #fff;
	}
	.titleText{
		color: rgba(255, 255, 255, 100);
		font-size: 22px;
		text-align: left;
		font-weight: 600;
		font-family: 方正工业黑-标准;
		margin: 40upx 0;
	}
	.miList{
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 30upx 0;
		color:rgba(153, 155, 178, 100);
	}
	
</style>