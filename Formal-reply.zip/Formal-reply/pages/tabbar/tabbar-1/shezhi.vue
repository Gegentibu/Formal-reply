<template>
	<view class="Hybody">
		<view class="titleText">
			设置
		</view>
		<view class="miList">
			<view class="">
				个人信息
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList">
			<view class="">
				实名认证
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList" style="margin-top: 100upx;">
			<view class="">
				通知设置
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList">
			<view class="">
				隐私设置
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList">
			<view class="">
				银行账户
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList"  style="margin-top: 100upx;">
			<view class="">
				关于“答复Ang-about”
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList">
			<view class="">
				意见反馈
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList"  style="margin-top: 100upx;">
			<view class="">
				联系我们
			</view>
			<view class="">
				>
			</view>
		</view>
	</view>
</template>

<script>
	
</script>

<style>
	.Hybody{
		padding: 0 60upx;
		height: 1500upx;
		font-size: 14px;
		background-color: #080808;
		color: #fff;
		padding-top: 50upx;
	}
	.titleText{
		color: rgba(255, 255, 255, 100);
		font-size: 22px;
		text-align: left;
		font-weight: 600;
		font-family: 方正工业黑-标准;
		margin: 40upx 0;
	}
	.miList{
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 10upx 0;
		color:rgba(153, 155, 178, 100);
	}
	
</style>