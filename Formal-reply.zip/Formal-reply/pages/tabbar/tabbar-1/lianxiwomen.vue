<template>
	<view class="Hybody">
		<view class="titleText">
			联系我们
		</view>
		<view class="">
			工作时间
		</view>
		<view class="" style="margin: 50upx 0;">
			工作日 早9：00—晚18：00
		</view>
		<view class="">
			热线电话
		</view>
		<view class=""  style="margin: 50upx 0;">
			0471 - 3591449   周一到周五9:00 -18:00
		</view>
		<view class="HyFlexC">
			<image src="../../../static/logo.png" mode=""></image>
		</view>
		<view class="HyFlexC">
			通过公众号
		</view>
		<view class="HyFlexC">
			联系我们
		</view>
	</view>
</template>

<script>
	
</script>

<style>
	.Hybody{
		padding: 0 60upx;
		padding-top: 50upx;
		height: 1500upx;
		font-size: 14px;
		background-color: #080808;
		color: #fff;
	}
	.titleText{
		color: rgba(255, 255, 255, 100);
		font-size: 22px;
		text-align: left;
		font-weight: 600;
		font-family: 方正工业黑-标准;
		margin: 40upx 0;
	}
	.miList{
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 30upx 0;
		color:rgba(153, 155, 178, 100);
	}
	.tijiao{
		width: 304upx;
		height: 63upx;
		line-height: 63upx;
		border-radius: 25upx;
		background-color: rgba(149, 70, 232, 100);
		color: rgba(255, 255, 255, 100);
		font-size: 14px;
		text-align: center;
		font-family: Microsoft Yahei;
	}
	image {
		width: 250upx;
		height: 250upx;
	}
	.HyFlexC{
		display: flex;
		justify-content: center;
		align-items: center;
	}
</style>