<template>
	<view class="Hybody">
		<view class="titleText">
			个人信息
		</view>
		<view class="miList">
			<view class="">
				头像
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList">
			<view class="">
				昵称
			</view>
			<view class="">
				Ended>
			</view>
		</view>
		<view class="miList">
			<view class="">
				格言
			</view>
			<view class="">
				越自由越自律>
			</view>
		</view>
		<view class="miList">
			<view class="">
				性别
			</view>
			<view class="">
				女>
			</view>
		</view>
		<view class="miList">
			<view class="">
				生日
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList">
			<view class="">
				地区
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList">
			<view class="">
				所在行业
			</view>
			<view class="">
				>
			</view>
		</view>
		<view class="miList">
			<view class="">
				我的职业
			</view>
			<view class="">
				>
			</view>
		</view>
	</view>
</template>

<script>
	
</script>

<style>
	.Hybody{
		padding: 0 60upx;
		padding-top: 50upx;
		height: 1500upx;
		font-size: 14px;
		background-color: #080808;
		color: #fff;
	}
	.titleText{
		color: rgba(255, 255, 255, 100);
		font-size: 22px;
		text-align: left;
		font-weight: 600;
		font-family: 方正工业黑-标准;
		margin: 40upx 0;
	}
	.miList{
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 30upx 0;
		color:rgba(153, 155, 178, 100);
	}
	
</style>