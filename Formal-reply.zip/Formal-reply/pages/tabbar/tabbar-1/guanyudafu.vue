<template>
	<view class="Hybody">
		<view class="titleText">
			关于“答复”   Past-hope
		</view>
		<view class="HyFlexC">
			<image src="../../../static/logo.png" mode=""></image>
		</view>
		<view class="titleText">
			答复
		</view>
		<view class="HyFlexC">
			Past - hope
		</view>
		<view class="HyFlexC" style="color:#F36D11;">
			1.0.0版
		</view>
		<view class="" style="margin-top: 200upx;color:#9546E8;">
		   《昔望Past-hope服务使用协议》
		</view>
		<view class="" style="color:#9546E8;">
			《昔望Past-hope个人信息保护政策》
		</view>
		<view class="" style="color:#9546E8;">
			Copyright     2020-2020 Hands-up
		</view>
	</view>
</template>

<script>
	
</script>

<style scoped>
	.Hybody{
		padding: 0 60upx;
		padding-top: 50upx;
		height: 1500upx;
		font-size: 14px;
		background-color: #080808;
		color: #fff;
		text-align: center;
	}
	.titleText{
		color: rgba(255, 255, 255, 100);
		font-size: 22px;
		text-align: center;
		font-weight: 600;
		font-family: 方正工业黑-标准;
		margin: 40upx 0;
	}
	.miList{
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 30upx 0;
		color:rgba(153, 155, 178, 100);
	}
	.tijiao{
		width: 304upx;
		height: 63upx;
		line-height: 63upx;
		border-radius: 25upx;
		background-color: rgba(149, 70, 232, 100);
		color: rgba(255, 255, 255, 100);
		font-size: 14px;
		text-align: center;
		font-family: Microsoft Yahei;
	}
	image {
		width: 250upx;
		height: 250upx;
	}
	.HyFlexC{
		display: flex;
		justify-content: center;
		align-items: center;
	}
</style>